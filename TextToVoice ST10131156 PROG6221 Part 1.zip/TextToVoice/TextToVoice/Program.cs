﻿using System;

using System.Speech.Synthesis;


namespace TextToVoice
{
    internal class Program
    {
       
        static void Main(string[] args)
        {
            SpeechSynthesizer voice = new SpeechSynthesizer();
           
            //configure the synthesizer
            voice.Volume = 100;
            voice.Rate = -1;

            // Speak a message
            Console.WriteLine("Hello, World!");
            voice.Speak("Hello How can i help you");

            //Speak User input
            Console.WriteLine("Enter Something to say : ");
            string usertext = Console.ReadLine();
            voice.Speak(usertext);

            Console.WriteLine("Goodbye");


        }
    }
}
